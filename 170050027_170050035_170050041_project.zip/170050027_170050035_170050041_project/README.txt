CS 663: DIP
Project Submission

Team: Aman Kansal, Ansh Khurana, Kushagra Juneja
Roll no: 170050027, 170050035, 170050041


## For running experiments:

exp_tr_blocksize - ablation of transfer with blocksize
exp_tr_iters - ablation of transfer with iterations
exp_syn - ablation of synthesis

synthesis.m and transfer.m have the main implementation of the algorithms.